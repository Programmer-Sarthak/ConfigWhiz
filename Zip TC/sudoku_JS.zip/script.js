let board = [];
let solution = [];
let selectedCell = null;

document.addEventListener('DOMContentLoaded', () => {
    newGame();
    
    // Keyboard support
    document.addEventListener('keydown', (e) => {
        if (!selectedCell) return;
        
        const key = e.key;
        if (key >= '1' && key <= '9') {
            inputNumber(parseInt(key));
        } else if (key === 'Backspace' || key === 'Delete') {
            inputNumber('Delete');
        } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(key)) {
            moveSelection(key);
        }
    });
});

function newGame() {
    const difficulty = parseInt(document.getElementById('difficulty').value);
    generateBoard(difficulty);
    renderBoard();
    document.getElementById('status-msg').innerText = '';
}

// --- Logic: Board Generation ---

function generateBoard(removedCount) {
    // 1. Create a base solved board
    solution = Array(81).fill(0);
    fillBoard(solution);
    
    // 2. Clone it to create the playable board
    board = [...solution];
    
    // 3. Remove numbers to create the puzzle
    let attempts = removedCount;
    while (attempts > 0) {
        let idx = Math.floor(Math.random() * 81);
        if (board[idx] !== 0) {
            board[idx] = 0;
            attempts--;
        }
    }
}

function fillBoard(grid) {
    // Simple backtracking to fill the board with a valid solution
    const find = findEmpty(grid);
    if (!find) return true; // Board full

    const [row, col] = find;
    const nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);

    for (let num of nums) {
        if (isValid(grid, num, row, col)) {
            grid[row * 9 + col] = num;
            if (fillBoard(grid)) return true;
            grid[row * 9 + col] = 0;
        }
    }
    return false;
}

function isValid(grid, num, row, col) {
    // Check row
    for (let x = 0; x < 9; x++) {
        if (grid[row * 9 + x] === num && x !== col) return false;
    }
    // Check col
    for (let x = 0; x < 9; x++) {
        if (grid[x * 9 + col] === num && x !== row) return false;
    }
    // Check box
    const startRow = Math.floor(row / 3) * 3;
    const startCol = Math.floor(col / 3) * 3;
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (grid[(startRow + i) * 9 + (startCol + j)] === num && 
                (startRow + i !== row || startCol + j !== col)) {
                return false;
            }
        }
    }
    return true;
}

function findEmpty(grid) {
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (grid[i * 9 + j] === 0) return [i, j];
        }
    }
    return null;
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// --- UI: Rendering & Interaction ---

function renderBoard() {
    const container = document.getElementById('sudoku-board');
    container.innerHTML = '';
    
    board.forEach((num, index) => {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.dataset.index = index;
        
        // Styling borders for 3x3 grids visually
        const row = Math.floor(index / 9);
        const col = index % 9;
        
        if (col === 2 || col === 5) cell.style.borderRight = "2px solid var(--grid-line)";
        if (row === 2 || row === 5) cell.style.borderBottom = "2px solid var(--grid-line)";

        if (num !== 0) {
            cell.innerText = num;
            cell.classList.add('fixed');
        } else {
            cell.classList.add('user-input');
            cell.onclick = () => selectCell(cell);
        }
        
        container.appendChild(cell);
    });
    selectedCell = null;
}

function selectCell(cell) {
    if (cell.classList.contains('fixed')) return;

    // Remove previous selection
    if (selectedCell) selectedCell.classList.remove('selected');
    
    // Highlight neighbors logic could go here, but kept simple for now
    
    selectedCell = cell;
    selectedCell.classList.add('selected');
}

function inputNumber(num) {
    if (!selectedCell) return;
    
    if (num === 'Delete') {
        selectedCell.innerText = '';
        selectedCell.classList.remove('error');
        return;
    }

    selectedCell.innerText = num;
    
    // Immediate validation check (Visual feedback)
    const idx = parseInt(selectedCell.dataset.index);
    const row = Math.floor(idx / 9);
    const col = idx % 9;
    
    // Temporarily build current grid state to check validity
    const currentGrid = getCurrentGrid();
    
    if (!isValid(currentGrid, num, row, col)) {
        selectedCell.classList.add('error');
    } else {
        selectedCell.classList.remove('error');
    }
    
    // Check for game completion
    if (currentGrid.every(n => n !== 0) && !document.querySelector('.error')) {
        document.getElementById('status-msg').innerText = "Congratulations! You solved it!";
    }
}

function getCurrentGrid() {
    const cells = document.querySelectorAll('.cell');
    const grid = [];
    cells.forEach(c => {
        const val = parseInt(c.innerText);
        grid.push(isNaN(val) ? 0 : val);
    });
    return grid;
}

function checkSolution() {
    const currentGrid = getCurrentGrid();
    const cells = document.querySelectorAll('.cell');
    let isCorrect = true;

    cells.forEach((cell, idx) => {
        if (cell.innerText === '') return; // Ignore empty
        const val = parseInt(cell.innerText);
        if (val !== solution[idx]) {
            cell.classList.add('error');
            isCorrect = false;
        }
    });
    
    const msg = document.getElementById('status-msg');
    msg.innerText = isCorrect ? "Looking good so far!" : "Some errors found (highlighted in red).";
}

function solveGameVisual() {
    // Fill the board with the pre-calculated solution
    const cells = document.querySelectorAll('.cell');
    cells.forEach((cell, idx) => {
        if (!cell.classList.contains('fixed')) {
            cell.innerText = solution[idx];
            cell.classList.remove('error');
            cell.style.color = "#27ae60"; // Show solved numbers in green
        }
    });
    document.getElementById('status-msg').innerText = "Solved!";
}

function moveSelection(key) {
    if (!selectedCell) return;
    const idx = parseInt(selectedCell.dataset.index);
    let newIdx = idx;

    if (key === 'ArrowUp') newIdx -= 9;
    if (key === 'ArrowDown') newIdx += 9;
    if (key === 'ArrowLeft') newIdx -= 1;
    if (key === 'ArrowRight') newIdx += 1;

    // Boundary checks
    if (newIdx < 0 || newIdx >= 81) return;

    // Find the cell at newIdx
    const cells = document.querySelectorAll('.cell');
    const target = cells[newIdx];
    
    // Only select if it's not fixed
    if (!target.classList.contains('fixed')) {
        selectCell(target);
    }
}