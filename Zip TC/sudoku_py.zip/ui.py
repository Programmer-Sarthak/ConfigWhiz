import tkinter as tk
from tkinter import messagebox, font
from logic import SudokuLogic

class SudokuUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Sudoku")
        self.root.geometry("400x550")
        self.root.configure(bg="#f0f4f8")

        self.logic = SudokuLogic()
        self.cells = {}  # Dictionary to store Entry widgets
        self.difficulty_level = tk.StringVar(value="Medium")

        # Fonts
        self.default_font = font.Font(family="Helvetica", size=14)
        self.bold_font = font.Font(family="Helvetica", size=14, weight="bold")

        self._create_layout()
        self.start_new_game()

    def _create_layout(self):
        # Title
        tk.Label(self.root, text="Sudoku", font=("Helvetica", 24, "bold"), 
                 bg="#f0f4f8", fg="#34495e").pack(pady=10)

        # Controls
        controls_frame = tk.Frame(self.root, bg="#f0f4f8")
        controls_frame.pack(pady=5)

        options = ["Easy", "Medium", "Hard"]
        dropdown = tk.OptionMenu(controls_frame, self.difficulty_level, *options)
        dropdown.config(width=8, font=("Helvetica", 10))
        dropdown.grid(row=0, column=0, padx=5)

        tk.Button(controls_frame, text="New Game", command=self.start_new_game, 
                  bg="#34495e", fg="white", font=("Helvetica", 10, "bold")).grid(row=0, column=1, padx=5)

        # Grid Container
        grid_container = tk.Frame(self.root, bg="#34495e", padx=2, pady=2)
        grid_container.pack(pady=20)

        vcmd = (self.root.register(self._validate_input), '%P')

        for row in range(9):
            for col in range(9):
                top_pad = 2 if row % 3 == 0 and row != 0 else 1
                left_pad = 2 if col % 3 == 0 and col != 0 else 1
                
                cell_frame = tk.Frame(grid_container, bg="white", width=40, height=40)
                cell_frame.grid(row=row, column=col, padx=(left_pad, 1), pady=(top_pad, 1))
                cell_frame.grid_propagate(False)

                cell = tk.Entry(cell_frame, font=self.default_font, justify="center", bd=0, 
                                validate="key", validatecommand=vcmd)
                cell.pack(fill="both", expand=True)
                self.cells[(row, col)] = cell

        # Action Buttons
        action_frame = tk.Frame(self.root, bg="#f0f4f8")
        action_frame.pack(pady=10)

        tk.Button(action_frame, text="Check Solution", command=self.check_solution, 
                  bg="#95a5a6", fg="white", width=12).grid(row=0, column=0, padx=5)

        tk.Button(action_frame, text="Solve Game", command=self.solve_game, 
                  bg="#95a5a6", fg="white", width=12).grid(row=0, column=1, padx=5)

    def _validate_input(self, P):
        if P == "" or (len(P) == 1 and P.isdigit() and 1 <= int(P) <= 9):
            return True
        return False

    def start_new_game(self):
        # Clear UI
        for row in range(9):
            for col in range(9):
                cell = self.cells[(row, col)]
                cell.config(state="normal", bg="white", fg="#2980b9")
                cell.delete(0, tk.END)

        # Get Logic
        diff = self.difficulty_level.get()
        self.board_data, self.solution_data = self.logic.generate_game(diff)

        # Draw Board
        for row in range(9):
            for col in range(9):
                val = self.board_data[row][col]
                cell = self.cells[(row, col)]
                if val != 0:
                    cell.insert(0, str(val))
                    cell.config(state="disabled", disabledbackground="white", 
                                disabledforeground="#2c3e50", font=self.bold_font)
                else:
                    cell.config(font=self.default_font)

    def check_solution(self):
        is_correct = True
        has_empty = False
        
        for row in range(9):
            for col in range(9):
                cell = self.cells[(row, col)]
                if cell['state'] == 'disabled': continue

                val = cell.get()
                if val == "":
                    has_empty = True
                    continue

                if int(val) != self.solution_data[row][col]:
                    cell.config(bg="#ffcdd2")
                    is_correct = False
                else:
                    cell.config(bg="white")

        if is_correct and not has_empty:
            messagebox.showinfo("Sudoku", "Congratulations! You solved it!")
        elif not is_correct:
            messagebox.showwarning("Sudoku", "There are mistakes (highlighted in red).")

    def solve_game(self):
        for row in range(9):
            for col in range(9):
                cell = self.cells[(row, col)]
                if cell['state'] != 'disabled':
                    cell.config(bg="white", fg="#27ae60")
                    cell.delete(0, tk.END)
                    cell.insert(0, str(self.solution_data[row][col]))
