import random

class SudokuLogic:
    def __init__(self):
        self.solution = []
        self.board = []

    def generate_game(self, difficulty="Medium"):
        """Generates a new puzzle and solution based on difficulty."""
        # 1. Create a base solved board
        self.solution = [[0 for _ in range(9)] for _ in range(9)]
        self.fill_board(self.solution)
        
        # 2. Clone it to create the playable board
        self.board = [row[:] for row in self.solution]
        
        # 3. Determine attempts based on difficulty
        attempts = 30 if difficulty == "Easy" else 40 if difficulty == "Medium" else 50
        
        # 4. Remove numbers
        self.remove_numbers(attempts)
        
        return self.board, self.solution

    def remove_numbers(self, attempts):
        """Randomly removes numbers to create the puzzle."""
        while attempts > 0:
            r = random.randint(0, 8)
            c = random.randint(0, 8)
            if self.board[r][c] != 0:
                self.board[r][c] = 0
                attempts -= 1

    def fill_board(self, grid):
        """Backtracking algorithm to fill the board."""
        empty = self.find_empty(grid)
        if not empty:
            return True # Board is full
        
        row, col = empty
        nums = list(range(1, 10))
        random.shuffle(nums) # Shuffle to get random solutions

        for num in nums:
            if self.is_valid(grid, num, row, col):
                grid[row][col] = num
                if self.fill_board(grid):
                    return True
                grid[row][col] = 0 # Backtrack
        
        return False

    def is_valid(self, grid, num, row, col):
        """Checks if a number can be placed at the given position."""
        # Check row
        if num in grid[row]: return False
        
        # Check col
        for r in range(9):
            if grid[r][col] == num: return False
            
        # Check 3x3 box
        box_row = (row // 3) * 3
        box_col = (col // 3) * 3
        for r in range(box_row, box_row + 3):
            for c in range(box_col, box_col + 3):
                if grid[r][c] == num: return False
                
        return True

    def find_empty(self, grid):
        """Finds the next empty cell (0)."""
        for r in range(9):
            for c in range(9):
                if grid[r][c] == 0:
                    return (r, c)
        return None
