package com.mycompany.app;
public class App {
    public static String getGreeting() {
        return "Hello world.";
    }
}