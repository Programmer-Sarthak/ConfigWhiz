import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;

public class SudokuUI extends JFrame {
    private SudokuLogic logic;
    private JTextField[][] cells;
    private JComboBox<String> difficultyBox;
    private Color bgColor = new Color(240, 244, 248);
    private Color gridLineColor = new Color(52, 73, 94);

    public SudokuUI() {
        logic = new SudokuLogic();
        cells = new JTextField[9][9];
        
        setTitle("Java Sudoku");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(bgColor);

        // --- Controls Panel ---
        JPanel controls = new JPanel();
        controls.setBackground(bgColor);
        
        String[] levels = {"Easy", "Medium", "Hard"};
        difficultyBox = new JComboBox<>(levels);
        difficultyBox.setSelectedIndex(1); // Default Medium
        
        JButton newGameBtn = new JButton("New Game");
        newGameBtn.addActionListener(e -> startNewGame());
        
        controls.add(new JLabel("Difficulty:"));
        controls.add(difficultyBox);
        controls.add(newGameBtn);
        
        add(controls, BorderLayout.NORTH);

        // --- Grid Panel ---
        JPanel gridPanel = new JPanel(new GridLayout(9, 9));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gridPanel.setBackground(gridLineColor);

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                JTextField cell = new JTextField();
                cell.setHorizontalAlignment(JTextField.CENTER);
                cell.setFont(new Font("SansSerif", Font.PLAIN, 20));
                
                // Input Filter (Numbers 1-9 only)
                ((AbstractDocument) cell.getDocument()).setDocumentFilter(new DigitFilter());
                
                // Custom Borders for 3x3 effect
                int top = (row % 3 == 0 && row != 0) ? 2 : 1;
                int left = (col % 3 == 0 && col != 0) ? 2 : 1;
                int bottom = 1; 
                int right = 1;
                
                cell.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, Color.GRAY));
                
                cells[row][col] = cell;
                gridPanel.add(cell);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

        // --- Action Buttons ---
        JPanel actions = new JPanel();
        actions.setBackground(bgColor);
        
        JButton checkBtn = new JButton("Check Solution");
        checkBtn.addActionListener(e -> checkSolution());
        
        JButton solveBtn = new JButton("Solve Game");
        solveBtn.addActionListener(e -> solveGame());
        
        actions.add(checkBtn);
        actions.add(solveBtn);
        
        add(actions, BorderLayout.SOUTH);
        
        // Start initial game
        startNewGame();
        setVisible(true);
    }

    private void startNewGame() {
        String diff = (String) difficultyBox.getSelectedItem();
        logic.generateGame(diff);
        int[][] board = logic.getBoard();

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                cells[i][j].setText("");
                cells[i][j].setBackground(Color.WHITE);
                cells[i][j].setEditable(true);
                cells[i][j].setForeground(new Color(41, 128, 185)); // User text color
                cells[i][j].setFont(new Font("SansSerif", Font.PLAIN, 20));

                if (board[i][j] != 0) {
                    cells[i][j].setText(String.valueOf(board[i][j]));
                    cells[i][j].setEditable(false);
                    cells[i][j].setForeground(new Color(44, 62, 80)); // Fixed text color
                    cells[i][j].setFont(new Font("SansSerif", Font.BOLD, 20));
                }
            }
        }
    }

    private void checkSolution() {
        int[][] solution = logic.getSolution();
        boolean correct = true;
        boolean emptyFound = false;

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (!cells[i][j].isEditable()) continue; // Skip fixed cells

                String text = cells[i][j].getText();
                if (text.isEmpty()) {
                    emptyFound = true;
                    continue;
                }

                int val = Integer.parseInt(text);
                if (val != solution[i][j]) {
                    cells[i][j].setBackground(new Color(255, 205, 210)); // Error red
                    correct = false;
                } else {
                    cells[i][j].setBackground(Color.WHITE);
                }
            }
        }

        if (correct && !emptyFound) {
            JOptionPane.showMessageDialog(this, "Congratulations! You solved it!");
        } else if (!correct) {
            JOptionPane.showMessageDialog(this, "Errors found (highlighted in red).");
        }
    }

    private void solveGame() {
        int[][] solution = logic.getSolution();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (cells[i][j].isEditable()) {
                    cells[i][j].setText(String.valueOf(solution[i][j]));
                    cells[i][j].setForeground(new Color(39, 174, 96)); // Green for auto-solve
                    cells[i][j].setBackground(Color.WHITE);
                }
            }
        }
    }

    // Filter to ensure only single digits 1-9 can be typed
    static class DigitFilter extends DocumentFilter {
        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            String newVal = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
            if (text.matches("[1-9]") && fb.getDocument().getLength() == 0) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}
