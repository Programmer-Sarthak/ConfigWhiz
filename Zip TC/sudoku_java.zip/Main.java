import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Run UI in the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new SudokuUI();
        });
    }
}