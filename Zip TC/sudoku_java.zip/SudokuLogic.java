import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class SudokuLogic {
    private int[][] solution;
    private int[][] board;
    private Random random;

    public SudokuLogic() {
        random = new Random();
    }

    public void generateGame(String difficulty) {
        // 1. Create a base solved board
        solution = new int[9][9];
        fillBoard(solution);

        // 2. Clone it to create the playable board
        board = new int[9][9];
        for (int i = 0; i < 9; i++) {
            System.arraycopy(solution[i], 0, board[i], 0, 9);
        }

        // 3. Determine numbers to remove based on difficulty
        int attempts;
        switch (difficulty) {
            case "Easy": attempts = 30; break;
            case "Hard": attempts = 50; break;
            default: attempts = 40; break; // Medium
        }

        removeNumbers(attempts);
    }

    private void removeNumbers(int attempts) {
        while (attempts > 0) {
            int r = random.nextInt(9);
            int c = random.nextInt(9);
            if (board[r][c] != 0) {
                board[r][c] = 0;
                attempts--;
            }
        }
    }

    private boolean fillBoard(int[][] grid) {
        int[] empty = findEmpty(grid);
        if (empty == null) return true; // Board is full

        int row = empty[0];
        int col = empty[1];

        List<Integer> nums = new ArrayList<>();
        for (int i = 1; i <= 9; i++) nums.add(i);
        Collections.shuffle(nums);

        for (int num : nums) {
            if (isValid(grid, num, row, col)) {
                grid[row][col] = num;
                if (fillBoard(grid)) return true;
                grid[row][col] = 0; // Backtrack
            }
        }
        return false;
    }

    public boolean isValid(int[][] grid, int num, int row, int col) {
        // Check row
        for (int x = 0; x < 9; x++) {
            if (grid[row][x] == num && x != col) return false;
        }

        // Check col
        for (int x = 0; x < 9; x++) {
            if (grid[x][col] == num && x != row) return false;
        }

        // Check 3x3 box
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grid[startRow + i][startCol + j] == num) {
                    if ((startRow + i) != row || (startCol + j) != col) return false;
                }
            }
        }
        return true;
    }

    private int[] findEmpty(int[][] grid) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (grid[i][j] == 0) return new int[]{i, j};
            }
        }
        return null;
    }

    public int[][] getBoard() { return board; }
    public int[][] getSolution() { return solution; }
}